CREATE TABLE certificados (
  id INT AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(50) UNIQUE,
  nombre VARCHAR(100),
  curso VARCHAR(150),
  fecha_emision DATE
);