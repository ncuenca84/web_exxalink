<?php
/**
 * Conexión a base de datos MySQL - Exxalink S.A.S.
 */
$conexion = new mysqli("localhost", "exxa_certificados", "Mctec2015*", "exxa_certificados");
if ($conexion->connect_error) {
    die("Error de conexión a MySQL: " . $conexion->connect_error);
}
$conexion->set_charset("utf8mb4");
?>