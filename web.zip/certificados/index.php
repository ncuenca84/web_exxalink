<?php
include 'conexion.php';
$codigo = isset($_GET['codigo']) ? $_GET['codigo'] : '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Verificación de Certificado | Exxalink S.A.S.</title>
<link rel="stylesheet" href="estilos.css">
</head>
<body>
<div class="container">
<img src="assets/logo_exxalink.png" class="logo" alt="Exxalink">
<h2>Verificación de Certificado</h2>
<form method="get">
    <input type="text" name="codigo" placeholder="Ingrese el código del certificado" value="<?=htmlspecialchars($codigo)?>">
    <button type="submit">Verificar</button>
</form>
<?php
if (!empty($codigo)) {
    $stmt = $conexion->prepare("SELECT nombre, curso, fecha_emision FROM certificados WHERE codigo = ?");
    $stmt->bind_param("s", $codigo);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows > 0) {
        $c = $res->fetch_assoc();
        echo "<p class='valid'>✅ Certificado válido</p>";
        echo "<p><strong>Nombre:</strong> {$c['nombre']}</p>";
        echo "<p><strong>Curso:</strong> {$c['curso']}</p>";
        echo "<p><strong>Fecha de emisión:</strong> {$c['fecha_emision']}</p>";
        echo "<p>Emitido por: <strong>Exxalink S.A.S.</strong></p>";
    } else {
        echo "<p class='invalid'>❌ Certificado no válido</p>";
    }
}
?>
</div>
</body>
</html>