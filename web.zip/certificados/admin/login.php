<?php
session_start();
if (isset($_POST['usuario']) && isset($_POST['clave'])) {
    if ($_POST['usuario'] === 'admin' && $_POST['clave'] === 'exxalink2025') {
        $_SESSION['admin'] = true;
        header('Location: panel.php');
        exit;
    } else {
        $error = "Credenciales incorrectas.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Login - Panel Exxalink</title>
<link rel="stylesheet" href="../estilos.css">
</head>
<body>
<div class="container">
<img src="../assets/logo_exxalink.png" class="logo">
<h2>Acceso Administrativo</h2>
<?php if (!empty($error)) echo "<p class='invalid'>$error</p>"; ?>
<form method="post">
    <input type="text" name="usuario" placeholder="Usuario">
    <input type="password" name="clave" placeholder="Contraseña">
    <button type="submit">Ingresar</button>
</form>
</div>
</body>
</html>