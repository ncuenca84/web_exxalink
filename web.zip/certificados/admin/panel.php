<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit;
}
include '../conexion.php';
require_once '../phpqrcode/qrlib.php';

if (!file_exists('../qrs')) mkdir('../qrs');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $curso = $_POST['curso'];
    $fecha = $_POST['fecha'];
    $codigo = 'EXX-' . date('Y') . '-' . rand(1000,9999);
    $url = "https://exxalink.com/certificados/?codigo=" . $codigo;
    $qrFile = "../qrs/" . $codigo . ".png";
    QRcode::png($url, $qrFile, 'L', 4);
    $stmt = $conexion->prepare("INSERT INTO certificados (codigo, nombre, curso, fecha_emision) VALUES (?,?,?,?)");
    $stmt->bind_param("ssss", $codigo, $nombre, $curso, $fecha);
    $stmt->execute();
    $msg = "Certificado generado correctamente. Código: $codigo";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Panel de Administración - Exxalink</title>
<link rel="stylesheet" href="../estilos.css">
</head>
<body>
<div class="container">
<img src="../assets/logo_exxalink.png" class="logo">
<h2>Registrar Nuevo Certificado</h2>
<?php if (!empty($msg)) echo "<p class='valid'>$msg</p>"; ?>
<form method="post">
    <input type="text" name="nombre" placeholder="Nombre completo" required>
    <input type="text" name="curso" placeholder="Curso o capacitación" required>
    <input type="date" name="fecha" required>
    <button type="submit">Registrar y Generar QR</button>
</form>
<p><a href="logout.php">Cerrar sesión</a></p>
</div>
</body>
</html>