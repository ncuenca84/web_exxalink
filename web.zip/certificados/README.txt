SISTEMA DE VERIFICACIÓN DE CERTIFICADOS - EXXALINK S.A.S.

Base de datos: exxa_certificados
Usuario MySQL: exxa_certificados
Contraseña: Mctec2015*

Acceso administrativo:
URL: https://exxalink.com/certificados/admin/
Usuario: admin
Clave: exxalink2025

Verificación pública:
https://exxalink.com/certificados/?codigo=EXX-XXXX