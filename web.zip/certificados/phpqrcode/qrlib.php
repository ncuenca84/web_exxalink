<?php
/*
 * Librer��a PHP QRCode simplificada (uso local)
 * Fuente original: https://sourceforge.net/projects/phpqrcode/
 * Adaptada para Exxalink S.A.S.
 */

class QRcode {
    public static function png($text, $outfile = false, $level = 'L', $size = 4, $margin = 2) {
        $encoded = urlencode($text);
        $url = "https://api.qrserver.com/v1/create-qr-code/?size=" . (100 + $size * 25) . "x" . (100 + $size * 25) . "&data=" . $encoded;
        $data = file_get_contents($url);
        if ($data === false) {
            die("Error generando QR: no se pudo obtener la imagen del servidor.");
        }

        if ($outfile) {
            file_put_contents($outfile, $data);
        } else {
            header("Content-Type: image/png");
            echo $data;
        }
    }
}
?>
